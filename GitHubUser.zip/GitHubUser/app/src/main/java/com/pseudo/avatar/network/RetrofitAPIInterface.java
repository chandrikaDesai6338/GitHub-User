package com.pseudo.avatar.network;

import com.pseudo.avatar.model.User;
import com.pseudo.avatar.model.UserDetailModel;

import java.util.List;

import io.reactivex.Observable;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface RetrofitAPIInterface {

    @GET("users")
    Observable<List<User>> queryUser();

    @GET("users/{login}")
    Observable<UserDetailModel> queryUserDetails(@Path("login") String login);
}
