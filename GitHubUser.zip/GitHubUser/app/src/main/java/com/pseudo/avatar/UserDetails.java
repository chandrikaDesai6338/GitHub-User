package com.pseudo.avatar;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.QuickContactBadge;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.pseudo.avatar.model.UserDetailModel;
import com.pseudo.avatar.network.RetrofitAPIInterface;
import com.pseudo.avatar.network.RetrofitHelper;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.observers.DefaultObserver;
import io.reactivex.schedulers.Schedulers;

public class UserDetails extends AppCompatActivity {

    @NonNull
    private RetrofitAPIInterface retrofitAPIInterface;

    public UserDetailModel userDetailModel;
    TextView nametxt, follower, following, blogurl, public_repos, location;
    ImageView imageView;

    ProgressDialog ringProgressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_details);

        Intent intent = getIntent();
        userDetailModel = new UserDetailModel();
        String login = intent.getStringExtra("LOGIN");
        retrofitAPIInterface = new RetrofitHelper().getRetrofitAPIInterface();

        //loading dialog init
        ringProgressDialog = new ProgressDialog(this);
        ringProgressDialog.setMessage("Loading....Please wait");
        ringProgressDialog.show();

        nametxt = findViewById(R.id.nametxt);
        follower = findViewById(R.id.followers);
        following = findViewById(R.id.following);
        blogurl = findViewById(R.id.blogurl);
        imageView = findViewById(R.id.avatar1);
        public_repos = findViewById(R.id.public_repos);
        location = findViewById(R.id.location);
        requestDetails(login);


    }

    private void requestDetails(String login) {
        Observable<UserDetailModel> observable = retrofitAPIInterface.queryUserDetails(login);
        observable
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(new DefaultObserver<UserDetailModel>() {
                    @Override
                    public void onNext(UserDetailModel userDetailModel) {
                        UserDetails.this.userDetailModel = userDetailModel;
                        displayDetails(userDetailModel);
                    }

                    @Override
                    public void onError(Throwable e) {

                    }

                    @Override
                    public void onComplete() {
                        ringProgressDialog.dismiss();
                    }
                });
    }

    private void displayDetails(UserDetailModel userDetailModel) {


        RequestOptions options = new RequestOptions()
                .centerCrop()
                .placeholder(R.mipmap.ic_launcher_round)
                .error(R.mipmap.ic_launcher_round);

        Glide.with(this)
                .load(userDetailModel.getAvatarUrl()) // image url
                .apply(options)
                .into(imageView);

        nametxt.setText(userDetailModel.getName());
        follower.setText(userDetailModel.getFollowers().toString());
        following.setText(userDetailModel.getFollowing().toString());
        if (userDetailModel.getBlog() == null || userDetailModel.getBlog().trim().isEmpty()) {
            blogurl.setText("I dont have a blog yet!!!");
        }else {
            final String blog_url = userDetailModel.getBlog();
            blogurl.setText(userDetailModel.getBlog());
            blogurl.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(blog_url));
                    startActivity(i);
                }
            });
        }
        public_repos.setText(userDetailModel.getPublicRepos().toString());
        if(userDetailModel.getLocation() == null || userDetailModel.getLocation().trim().isEmpty()){
            location.setText("Location not found!!!");
        }else{
            location.setText(userDetailModel.getLocation());
        }

    }

}
