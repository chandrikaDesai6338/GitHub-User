package com.pseudo.avatar;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;

import com.pseudo.avatar.adapter.UserAdapter;
import com.pseudo.avatar.model.User;
import com.pseudo.avatar.model.UserResponse;
import com.pseudo.avatar.network.RetrofitAPIInterface;
import com.pseudo.avatar.network.RetrofitHelper;

import java.util.List;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Function;
import io.reactivex.observers.DefaultObserver;
import io.reactivex.schedulers.Schedulers;

public class MainActivity extends AppCompatActivity implements MainInterface, CustomItemClickListener {


    private static final String TAG = "Main";
    /**
     * Collects all subscriptions to unsubscribe later
     */
    @NonNull
    private CompositeDisposable compositeDisposable = new CompositeDisposable();

    @NonNull
    private RetrofitAPIInterface retrofitAPIInterface;

    private MainInterface mainInterface;
    RecyclerView.Adapter adapter;
    RecyclerView rvUsers;
    public UserResponse userResponse;

    public List<User> u;

    ProgressDialog ringProgressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Init Retrofit Interface
        retrofitAPIInterface = new RetrofitHelper().getRetrofitAPIInterface();

        //Init Object to receive user responce from api
        userResponse = new UserResponse();
        rvUsers = findViewById(R.id.rvUsers);

        //check Internet Availability
        if (!CheckConnectivity()) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(getString(R.string.internet))
                    .setCancelable(false)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            finish();
                        }
                    });
            AlertDialog alert = builder.create();
            alert.show();
        } else {
            //loading dialog init
            ringProgressDialog = new ProgressDialog(this);
            ringProgressDialog.setMessage(getString(R.string.loading));
            ringProgressDialog.show();

            requestUsers();
        }

    }

    private void requestUsers() {
        getAllUser().subscribe(new DefaultObserver<UserResponse>() {
            @Override
            public void onNext(UserResponse userResponse) {
                Log.d(TAG, "onNext user  = " + userResponse.getUser().get(1).getAvatarUrl());
                displayUser(userResponse.getUser());
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {
                ringProgressDialog.dismiss();
            }
        });
    }

    private void displayUser(List<User> users) {
        u = users;
        if (users != null) {
            Log.d(TAG, "");
            rvUsers.setLayoutManager(new LinearLayoutManager(MainActivity.this));
            adapter = new UserAdapter(users, MainActivity.this);
            ((UserAdapter) adapter).setOnItemClickListener(this);
            rvUsers.setAdapter(adapter);
        } else {
            Log.d(TAG, "User response null");
        }
    }

    // Getting data using Observable
    @Override
    public Observable<UserResponse> getAllUser() {
        Observable<List<User>> observable = retrofitAPIInterface.queryUser();
        return observable
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .flatMap(new Function<List<User>, Observable<UserResponse>>() {

                    @Override
                    public Observable<UserResponse> apply(List<User> users) throws Exception {
                        userResponse.setUser(users);
                        return Observable.just(userResponse);
                    }
                });
    }

    //when an element of recycler view is clicked
    @Override
    public void onItemClick(View v, int position) {

        Log.d(TAG, "clicked position:" + position);
        String login = u.get(position).getLogin();
        Intent intent = new Intent(MainActivity.this, UserDetails.class);
        intent.putExtra("LOGIN", login);
        startActivity(intent);
    }

    //Check Internet Availability
    public boolean CheckConnectivity() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            return true;
        } else {
            return false;
        }

    }
}
