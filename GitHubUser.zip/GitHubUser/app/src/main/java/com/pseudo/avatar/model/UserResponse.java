package com.pseudo.avatar.model;

import java.util.List;

public class UserResponse {

    public List<User> getUser() {
        return user;
    }

    public void setUser(List<User> user) {
        this.user = user;
    }

    public List<User> user;
}
