package com.pseudo.avatar.adapter;

import android.app.TimePickerDialog;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.pseudo.avatar.CustomItemClickListener;
import com.pseudo.avatar.R;
import com.pseudo.avatar.model.User;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserHolder> {

    private List<User> userList;
    private Context context;
    CustomItemClickListener listener;


    public UserAdapter(List<User> userList, Context context) {
        this.userList = userList;
        this.context = context;
    }

    public void setOnItemClickListener(CustomItemClickListener listener){
        this.listener = listener;
    }

    @Override
    public UserHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.single_user_row,parent,false);
        UserHolder mViewHolder = new UserHolder(v,listener);
        return mViewHolder;
    }

    @Override
    public void onBindViewHolder(UserHolder holder, int position) {
        holder.login.setText(userList.get(position).getLogin());
        RequestOptions options = new RequestOptions()
                .centerCrop()
                .placeholder(R.mipmap.ic_launcher_round)
                .error(R.mipmap.ic_launcher_round);
        Glide
                .with(context)
                .load(userList.get(position).getAvatarUrl())
                .apply(options)
                .into(holder.avatar);
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }


    public class UserHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView login;
        ImageView avatar;
        CustomItemClickListener mListener;

        public UserHolder(View v, CustomItemClickListener listener) {
            super(v);
            v.setTag(this);
            login = v.findViewById(R.id.login);
            avatar = v.findViewById(R.id.avatar);
            this.mListener = listener;
            v.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            if(mListener != null){
                mListener.onItemClick(v,getAdapterPosition());
            }
        }
    }
}