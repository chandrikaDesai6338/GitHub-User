package com.pseudo.avatar;

import com.pseudo.avatar.model.User;
import com.pseudo.avatar.model.UserResponse;

import io.reactivex.Observable;

public interface MainInterface {

    public Observable<UserResponse> getAllUser();
}
